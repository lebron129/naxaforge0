const connectBtn = document.getElementById('connectWallet');
const addressDisplay = document.getElementById('walletAddress');

connectBtn.onclick = async () => {
    if (window.ethereum) {
        try {
            const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
            addressDisplay.textContent = "Wallet connecté : " + accounts[0];
            loadServices();
        } catch (error) {
            alert("Connexion refusée.");
        }
    } else {
        alert("Installez MetaMask pour continuer.");
    }
};

function loadServices() {
    const services = [
        { name: "Pack Basique", price: 50 },
        { name: "Pack Standard", price: 200 },
        { name: "Pack Premium", price: 1000 },
        { name: "Pack Pro", price: 5000 },
        { name: "Pack Ultime", price: 10000 }
    ];

    const container = document.getElementById("serviceContainer");
    container.innerHTML = "";

    services.forEach(service => {
        const div = document.createElement("div");
        div.className = "service";
        div.innerHTML = `
            <h2>${service.name}</h2>
            <p>Prix : ${service.price} USD</p>
            <button onclick="orderService('${service.name}', ${service.price})">Commander</button>
        `;
        container.appendChild(div);
    });
}

function orderService(name, price) {
    alert(`Commande passée : ${name} pour ${price} USD (paiement simulé)`);
}
